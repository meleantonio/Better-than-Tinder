function rating
clear all; close all; clc;

pe1=[];

c_dir=cd;
n_dir=[c_dir filesep 'Image'];
num=1;
save num num;
cd(n_dir);
filee=dir('*.jpg');
im2=imread(filee(num).name);
cd(c_dir);
fg=figure('units','normalized','position',[0.5 0.5 .18 .4],'resize','off',...
    'numbertitle','off','Color',[.8 .9 .9],'menubar','none');
ui2=uipanel('parent',fg,'units','normalized','position',[0.1 0.25 .8 .75],'BackgroundColor','white');
ui2ax = axes('Units','normal', 'Position', [0 0 1 1], 'Parent', ui2);imagesc(im2);
img3=imread('hrt.jpg');img3=imresize(img3,[40,40]);
img1=imread('wstr.jpg');img1=imresize(img1,[20,20]);
p1=uicontrol('style','push','parent',fg,'units','normalized','position',[0.25 0.15 .1 .1],...
    'BackgroundColor',[1 1 1],'CData',img1);
p2=uicontrol('style','push','parent',fg,'units','normalized','position',[0.35 0.15 .1 .1],...
    'BackgroundColor',[1 1 1],'CData',img1);
p3=uicontrol('style','push','parent',fg,'units','normalized','position',[0.45 0.15 .1 .1],...
    'BackgroundColor',[1 1 1],'CData',img1);
p4=uicontrol('style','push','parent',fg,'units','normalized','position',[0.55 0.15 .1 .1],...
    'BackgroundColor',[1 1 1],'CData',img1);
p5=uicontrol('style','push','parent',fg,'units','normalized','position',[0.65 0.15 .1 .1],...
    'BackgroundColor',[1 1 1],'CData',img1);
pl=uicontrol('style','push','parent',fg,'units','normalized','position',[0 0.55 .1 .25],...
    'string','<<');
pr=uicontrol('style','push','parent',fg,'units','normalized','position',[0.9 .55 .1 .25],...
    'string','>>');
pd=uicontrol('style','push','parent',fg,'units','normalized','position',[0 0 1 .15],...
    'CData',img3,'string','Like','fontsize',18,'BackgroundColor',[1 1 1]);
Data = uitable(fg, 'Data', [],'units','normalized', ...
                   'Position', [.5 .5 .3 .5],'visible','off');

set(p1,'callback',{@cb_p1,p1});
set(p2,'callback',{@cb_p2,p2});
set(p3,'callback',{@cb_p3,p3});
set(p4,'callback',{@cb_p4,p4});
set(p5,'callback',{@cb_p5,p5});
set(pl,'callback',{@cb_pl,c_dir,n_dir,ui2,ui2ax,p1,p2,p3,p4,p5,img1});
set(pr,'callback',{@cb_pr,c_dir,n_dir,ui2,ui2ax,p1,p2,p3,p4,p5,img1});
set(pd,'callback',{@cb_pd,p1,p2,p3,p4,p5,Data});



end

function cb_p1(hobject,eventdata,p1)
img2=imread('ystr.jpg');img2=imresize(img2,[20,20]);
img1=imread('wstr.jpg');img1=imresize(img1,[20,20]);
img=get(p1,'cdata');img=corr2(rgb2gray(img),rgb2gray(img1));
if img==1
    set(p1,'CData',img2);
else
    set(p1,'CData',img1);
end
end

function cb_p2(hobject,eventdata,p2)
img2=imread('ystr.jpg');img2=imresize(img2,[20,20]);
img1=imread('wstr.jpg');img1=imresize(img1,[20,20]);
img=get(p2,'cdata');img=corr2(rgb2gray(img),rgb2gray(img1));
if img==1
    set(p2,'CData',img2);
else
    set(p2,'CData',img1);
end
end

function cb_p3(hobject,eventdata,p3)
img2=imread('ystr.jpg');img2=imresize(img2,[20,20]);
img1=imread('wstr.jpg');img1=imresize(img1,[20,20]);
img=get(p3,'cdata');img=corr2(rgb2gray(img),rgb2gray(img1));
if img==1
    set(p3,'CData',img2);
else
    set(p3,'CData',img1);
end
end

function cb_p4(hobject,eventdata,p4)
img2=imread('ystr.jpg');img2=imresize(img2,[20,20]);
img1=imread('wstr.jpg');img1=imresize(img1,[20,20]);
img=get(p4,'cdata');img=corr2(rgb2gray(img),rgb2gray(img1));
if img==1
    set(p4,'CData',img2);
else
    set(p4,'CData',img1);
end
end

function cb_p5(hobject,eventdata,p5)
img2=imread('ystr.jpg');img2=imresize(img2,[20,20]);
img1=imread('wstr.jpg');img1=imresize(img1,[20,20]);
img=get(p5,'cdata');img=corr2(rgb2gray(img),rgb2gray(img1));
if img==1
    set(p5,'CData',img2);
else
    set(p5,'CData',img1);
end
end



function cb_pl(hobject,eventdata,c_dir,n_dir,ui2,ui2ax,p1,p2,p3,p4,p5,img1)
load num;num=num-1;
cd(n_dir);
filee=dir('*.jpg');
if num==0
    num=1;
end;
set(p1,'CData',img1);
set(p2,'CData',img1);
set(p3,'CData',img1);
set(p4,'CData',img1);
set(p5,'CData',img1);
im1=imread(filee(num).name);
ui2ax = axes('Units','normal', 'Position', [0 0 1 1], 'Parent', ui2);imagesc(im1);
cd(c_dir);
save num num;
end

function cb_pr(hobject,eventdata,c_dir,n_dir,ui2,ui2ax,p1,p2,p3,p4,p5,img1)
load num;num=num+1;
cd(n_dir);
filee=dir('*.jpg');
if num>length(filee)
    num=length(filee);
end;
set(p1,'CData',img1);
set(p2,'CData',img1);
set(p3,'CData',img1);
set(p4,'CData',img1);
set(p5,'CData',img1);
im1=imread(filee(num).name);
ui2ax = axes('Units','normal', 'Position', [0 0 1 1], 'Parent', ui2);imagesc(im1);
cd(c_dir);
save num num;
end

function cb_pd(hobject,eventdata,p1,p2,p3,p4,p5,Data)

img2=imread('ystr.jpg');img2=imresize(img2,[20,20]);
imgg1=get(p1,'cdata');imgg1=corr2(rgb2gray(imgg1),rgb2gray(img2));
imgg2=get(p2,'cdata');imgg2=corr2(rgb2gray(imgg2),rgb2gray(img2));
imgg3=get(p3,'cdata');imgg3=corr2(rgb2gray(imgg3),rgb2gray(img2));
imgg4=get(p4,'cdata');imgg4=corr2(rgb2gray(imgg4),rgb2gray(img2));
imgg5=get(p5,'cdata');imgg5=corr2(rgb2gray(imgg5),rgb2gray(img2));
sm=sum(round([imgg1 imgg2 imgg3 imgg4 imgg5]));

pers=round(sm*100/5);
Dat=get(Data,'Data');
if isempty(Dat)
   Dat=pers;
else
  Dat=[Dat,pers];
end
set(Data,'Data',Dat);
d=get(Data,'Data');
[val,pos]=sort(d,'descend');
% disp(val)
% disp(pos);
% disp(['Like  in Percentage:',num2str(pers)])


if length(pos)==4
                  % Number of men/women
 disp(val)
 disp(pos)


end
end