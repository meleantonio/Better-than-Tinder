function pushbutton1_Callback(hObject, eventdata, handles)
% create the random numbers
x = {randi(42,1,1)  randi(42,1,1)};
% get the current table data
data = get(handles.uitable1,'Data');
if isempty(data)
    data = x;
else
    % append the new row
    data = [data ; x];
end
% update the table
set(handles.uitable1,'Data',data);